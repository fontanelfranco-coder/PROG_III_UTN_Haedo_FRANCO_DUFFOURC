<?php
// perfil.php — Sube o quita la foto de perfil del usuario (no tiene pantalla propia)
require 'includes/config.php';

$yo = requerir_rol('General');
$volver = 'generales.php#perfil';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirigir($volver);
}

// Si el archivo supera post_max_size de php.ini, PHP descarta TODO el formulario
// (llega $_POST vacío). Lo detectamos para dar un mensaje claro.
if (empty($_POST) && empty($_FILES) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    flash('error', 'La imagen es demasiado grande. El máximo es 2 MB.');
    redirigir($volver);
}
verificar_csrf($volver);

$st = db()->prepare('SELECT foto FROM usuarios WHERE documento = :doc');
$st->execute([':doc' => $yo['documento']]);
$fotoActual = $st->fetchColumn() ?: null;

// ---------------------------------------------------------------- Quitar foto
if (($_POST['accion'] ?? '') === 'quitar') {
    db()->prepare('UPDATE usuarios SET foto = NULL WHERE documento = :doc')->execute([':doc' => $yo['documento']]);
    borrar_foto($fotoActual);
    $_SESSION['foto'] = null;
    flash('exito', 'Quitaste tu foto de perfil.');
    redirigir($volver);
}

// ---------------------------------------------------------------- Subir foto
$archivo = $_FILES['foto'] ?? null;
$error = $archivo['error'] ?? UPLOAD_ERR_NO_FILE;

if ($error === UPLOAD_ERR_NO_FILE) {
    flash('error', 'Elegí una imagen para subir.');
    redirigir($volver);
}
if ($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE || $archivo['size'] > FOTO_MAX_BYTES) {
    flash('error', 'La imagen es demasiado grande. El máximo es 2 MB.');
    redirigir($volver);
}
if ($error !== UPLOAD_ERR_OK || !is_uploaded_file($archivo['tmp_name'])) {
    flash('error', 'No pudimos recibir la imagen. Intentá de nuevo.');
    redirigir($volver);
}

// 1. Tipo REAL del archivo: se lee su contenido, no se confía en la extensión
//    ni en el tipo que informa el navegador (ambos los controla quien sube).
$permitidos = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
$tipo = (new finfo(FILEINFO_MIME_TYPE))->file($archivo['tmp_name']);

// 2. Además tiene que poder leerse como imagen (ancho y alto válidos)
$medidas = @getimagesize($archivo['tmp_name']);

if (!isset($permitidos[$tipo]) || !$medidas || $medidas[0] < 1 || $medidas[0] > 6000 || $medidas[1] > 6000) {
    flash('error', 'El archivo tiene que ser una imagen JPG, PNG o WEBP.');
    redirigir($volver);
}

// 3. Nombre nuevo y aleatorio: nunca se usa el nombre original del archivo
$nombre = bin2hex(random_bytes(16)) . '.' . $permitidos[$tipo];
$carpeta = __DIR__ . '/' . CARPETA_FOTOS;
if (!is_dir($carpeta)) {
    mkdir($carpeta, 0755, true);
}

if (!move_uploaded_file($archivo['tmp_name'], $carpeta . $nombre)) {
    flash('error', 'No pudimos guardar la imagen. Revisá los permisos de la carpeta uploads.');
    redirigir($volver);
}

// 4. Guardamos el nombre en la base y borramos la foto anterior
db()->prepare('UPDATE usuarios SET foto = :f WHERE documento = :doc')
    ->execute([':f' => $nombre, ':doc' => $yo['documento']]);
borrar_foto($fotoActual);
$_SESSION['foto'] = $nombre;

flash('exito', 'Actualizaste tu foto de perfil.');
redirigir($volver);
